# wscraping_helper
Python module origin github repository

## Command:

- get_html_data(): Querying html data from the URL address
- toString(): Returns the text of all the data in the array to another array.
- getAttributes(): Similar to the previous one. Returns the value of the given attributes of all the data of an array to another array.
- child_tags(): Returns tags within a given element according to criteria
